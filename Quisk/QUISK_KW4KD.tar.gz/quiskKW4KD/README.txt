The information from this file is now in docs.html.
