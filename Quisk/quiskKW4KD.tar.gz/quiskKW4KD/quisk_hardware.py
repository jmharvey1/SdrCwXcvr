# This is my HomeBrew SoftRock like SDR using a AD9850 DDS VFO & SS Micro (Arduino) as a USB serial interface
# it to your own quisk_hardware.py and make changes there.
# See quisk_hardware_model.py for documentation.
#
# This hardware module sends the IF output of an AOR SftRkSDR
# to the input of an SDR-IQ by RfSpace
#

import time
import _quisk as QS
from sdriqpkg import sdriq
import serial			# From the pyserial package
import struct, threading, time, traceback, math ## JMH 20180227 Added the following in an attempt to support hombrew ssmicro/si5351 sdr as a tramsmitter
                                                ## this code in its original form was taken from softrock/hardware_usb.py file
#from softrock import widgets_tx   as quisk_widgets

from quisk_hardware_model import Hardware as BaseHardware

#class Hardware(BaseHardware):
#  def __init__(self, app, conf):
#    BaseHardware.__init__(self, app, conf)
#    self.vfo = self.conf.fixed_vfo_freq		# Fixed VFO frequency in Hertz
#    self.tune = self.vfo + 10000		# Current tuning frequency in Hertz
#  def ChangeFrequency(self, tune, vfo, source='', band='', event=None):
#    # Change and return the tuning and VFO frequency.  See quisk_hardware_model.py.
#    self.tune = tune
#    return tune, self.vfo
#  def ReturnFrequency(self):
#    # Return the current tuning and VFO frequency.  See quisk_hardware_model.py.
#    return self.tune, self.vfo

# Use the SDR-IQ hardware as the base class
#from sdriqpkg import quisk_hardware as SdriqHardware
#BaseHardware = SdriqHardware.Hardware

class Hardware(BaseHardware):
  def __init__(self, app, conf):
    BaseHardware.__init__(self, app, conf)
    self.vfo_frequency = self.conf.fixed_vfo_freq		# current vfo frequency
    self.tune = self.vfo_frequency + 10000		# Current tuning frequency in Hertz
    self.is_cw = False                  ##20180226 JMH added this method to support SSmicro Si5351 TX setup
    self.ptt_button = 0                 ##20180226 JMH added this method to support SSmicro Si5351 TX setup
    self.key_thread = None              ##20180226 JMH added this method to support SSmicro Si5351 TX setup
    self.usb_dev = True                 ##20180226 JMH added this method to support SSmicro Si5351 TX setup
    self.CmdStr= ''                     ##20180226 JMH added this method to support SSmicro Si5351 TX setup
    self.tty_name = '/dev/ttyACM0'	# serial port name for SftRkSDR
    self.serial = None			# the open serial port
    self.timer = 0.02			# time between SftRkSDR commands in seconds
    self.time0 = 0			# time of last SftRkSDR command
    self.serial_out = []		# send commands slowly
    try:
      if not (conf.HrdwrTalk == None):
        self.HrdwrTalk = conf.HrdwrTalk
    except:
      self.HrdwrTalk = True
  def open(self):
    self.serial = serial.Serial(port=self.tty_name, baudrate=9600,
          stopbits=serial.STOPBITS_TWO, xonxoff=1, timeout=0)
    self.SendSftRkSDR('MD0\r')		# set WFM mode so the IF output is available
    # The SftRkSDR inverts the spectrum of the 2 meter and 70 cm bands.
    # Other bands may not be inverted, so we may need to test the frequency.
    # But this is not currently implemented.
    QS.invert_spectrum(1)
    t = BaseHardware.open(self)		# save the message
    sdriq.freq_sdriq(10700000)
    return t
  def close(self):
    BaseHardware.close(self)
    if self.serial:
      self.serial.write('EX\r')
      time.sleep(1)			# wait for output to drain, but don't block
      self.serial.close()
      self.serial = None
  def ChangeFrequency(self, rx_freq, vfo_freq, source='', band='', event=None):
    vfo_freq = (vfo_freq + 5000) / 10000 * 10000		# round frequency
    if vfo_freq != self.vfo_frequency and vfo_freq >= 100000:
      self.vfo_frequency = vfo_freq
      self.SendSftRkSDR('RF%010d\r' % vfo_freq)
    return rx_freq, vfo_freq
  def ChangeTXFreq(self, tx_freq): ##20180226 JMH added this method to support SSmicro Si5351 TX setup
    self.SendSftRkSDR('TX%010d\r' %tx_freq)
    return
  def SndKeyStream(self, keystream): ##201800708 JMH added this method to support SSmicro key via usb serial link
    self.SendSftRkSDR('KS%s\r' %keystream)
    return
  
  def ChangeBand(self, band):	# Defeat base class method
    return
  def ChangeMode(self, mode):	# Change the tx/rx mode  ##20180226 JMH added this method to support SSmicro Si5351 TX setup
    # mode is a string: "USB", "AM", etc.
    if mode in ('CWU', 'CWL'):
      self.is_cw = True
    else:
      self.is_cw = False
    if self.key_thread:
      self.key_thread.IsCW(self.is_cw)
    elif hasattr(self, 'OnButtonPTT'):
      self.OnButtonPTT()
  def SendSftRkSDR(self, msg):	# Send commands to the SftRkSDR, but not too fast
    if self.serial:
      if time.time() - self.time0 > self.timer:
        self.serial.write(msg)			# send message now
        self.time0 = time.time()
      else:
        self.serial_out.append(msg)		# send message later
   ## JMH 20180227 Added the following in an attempt to support hombrew ssmicro/si5351 sdr as a tramsmitter
  def OnSpot(self, level):
    if self.key_thread:
      self.key_thread.OnSpot(level)
  def OnButtonPTT(self, event=None):
    if event:
      if event.GetEventObject().GetValue():
        self.ptt_button = 1
        self.CmdStr= 'PTTON\r'
      else:
        self.ptt_button = 0
        self.CmdStr= 'PTTOFF\r'
    if self.key_thread:
      self.key_thread.OnPTT(self.ptt_button)
    elif self.usb_dev:
      if self.is_cw:
        QS.set_key_down(0)
        QS.set_transmit_mode(self.ptt_button)
      else:
        QS.set_key_down(self.ptt_button)
      try:
        self.SendSftRkSDR(self.CmdStr) #self.usb_dev.ctrl_transfer(IN, 0x50, self.ptt_button, 0, 3)
      except usb.core.USBError:
        if DEBUG: traceback.print_exc()
        try:
         self.SendSftRkSDR(self.CmdStr) #self.usb_dev.ctrl_transfer(IN, 0x50, self.ptt_button, 0, 3)
        except usb.core.USBError:
          if DEBUG: traceback.print_exc()   
      
  def HeartBeat(self):	# Called at about 10 Hz by the main
    BaseHardware.HeartBeat(self)
    if self.serial:
      chars = self.serial.read(1024)
      if chars:
        if(self.HrdwrTalk): print chars
      if self.serial_out and time.time() - self.time0 > self.timer:
        self.serial.write(self.serial_out[0])
        self.time0 = time.time()
        del self.serial_out[0]

## JMH 20180227 Added the following in an attempt to support hombrew ssmicro/si5351 sdr as a tramsmitter
## this code in its original form was taken from softrock/hardware_usb.py file
class KeyThread(threading.Thread):
  """Create a thread to monitor the key state."""
  def __init__(self, dev, poll_secs, key_hang_time):
    self.usb_dev = dev
    self.poll_secs = poll_secs
    self.key_hang_time = key_hang_time
    self.ptt_button = 0
    self.spot_level = -1	# level is -1 for Spot button Off; else the Spot level 0 to 1000.
    self.currently_in_tx = 0
    self.is_cw = False
    self.key_timer = 0
    self.key_transmit = 0
    threading.Thread.__init__(self)
    self.doQuit = threading.Event()
    self.doQuit.clear()
  def run(self):
    while not self.doQuit.isSet():
      try:		# Test key up/down state
        ret = self.usb_dev.ctrl_transfer(IN, 0x51, 0, 0, 1)
      except usb.core.USBError:
        key_down = None
        if DEBUG: traceback.print_exc()
      else:
        # bit 0x20 is the tip, bit 0x02 is the ring (ring not used)
        if ret[0] & 0x20 == 0:		# Tip: key is down
          key_down = True
        else:			# key is up
          key_down = False
      if self.is_cw:
        if self.spot_level >= 0 or key_down:		# key is down
          QS.set_key_down(1)
          self.key_transmit = 1
          self.key_timer = time.time()
        else:			# key is up
          QS.set_key_down(0)
          if self.key_transmit and time.time() - self.key_timer > self.key_hang_time:
            self.key_transmit = 0
        if self.key_transmit != self.currently_in_tx:
          try:
            self.usb_dev.ctrl_transfer(IN, 0x50, self.key_transmit, 0, 3)
          except usb.core.USBError:
            if DEBUG: traceback.print_exc()
          else:
            self.currently_in_tx = self.key_transmit	# success
            QS.set_transmit_mode(self.key_transmit)
            if DEBUG: print ("Change CW currently_in_tx", self.currently_in_tx)
      else:
        if key_down or self.ptt_button:
          self.key_transmit = 1
        else:
          self.key_transmit = 0
        if self.key_transmit != self.currently_in_tx:
          QS.set_key_down(self.key_transmit)
          try:
            self.usb_dev.ctrl_transfer(IN, 0x50, self.key_transmit, 0, 3)
          except usb.core.USBError:
            if DEBUG: traceback.print_exc()
          else:
            self.currently_in_tx = self.key_transmit	# success
            if DEBUG: print ("Change currently_in_tx", self.currently_in_tx)
      time.sleep(self.poll_secs)
  def stop(self):
    """Set a flag to indicate that the thread should end."""
    self.doQuit.set()
  def OnPTT(self, ptt):
    self.ptt_button = ptt
  def OnSpot(self, level):
    self.spot_level = level
  def IsCW(self, is_cw):
    self.is_cw = is_cw        
