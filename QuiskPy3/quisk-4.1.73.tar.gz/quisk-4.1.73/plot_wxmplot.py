# plot using the wxmplot package
