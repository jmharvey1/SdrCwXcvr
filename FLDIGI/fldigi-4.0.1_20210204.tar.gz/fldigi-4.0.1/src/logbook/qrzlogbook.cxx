// =====================================================================
//
// qrzlogbook.cxx
//
// Copyright (C) 2018
//		Jim, Harvey KW4KD
//
// This file is part of fldigi.
//
// Fldigi is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Fldigi is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with fldigi.  If not, see <http://www.gnu.org/licenses/>.
// =====================================================================

#include <iostream>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <list>
#include <stdlib.h>

#include <sys/socket.h> /* socket, connect */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <netdb.h> /* struct hostent, gethostbyname */

#include <FL/Fl_Text_Display.H>
//#include <FL/Fl_Text_messager.H>
/*
#include "fl_digi.h"
#include "rigsupport.h"
#include "modem.h"
#include "trx.h"
#include "configuration.h"

*/
#include "main.h"

#include "qrunner.h"
#include "debug.h"
#include "status.h"
#include "icons.h"
#include "threads.h"
#include "socket.h"
#include "network.h"
#include "fileselect.h"
#include "qrzlogbook.h"
#include "network.h"
#include "confdialog.h"
#include "dx_dialog.h"
/*
#include "logsupport.h"
#include "dx_dialog.h"
#include "dx_cluster.h"
#include "confdialog.h"
*/
using namespace std;
//#define QRZLGBK_DEBUG 1
#define QRZLGBK_LOOP_TIME 100 // milliseconds
#define QRZLGBK_CONNECT_TIMEOUT 50000 // 5 second timeout
#define QRZLGBK_SOCKET_TIMEOUT 100 // milliseconds
int  QRZLGBK_connect_timeout =
    (QRZLGBK_CONNECT_TIMEOUT) / (QRZLGBK_SOCKET_TIMEOUT + QRZLGBK_LOOP_TIME);

LOG_FILE_SOURCE(debug::LOG_FD);

pthread_t QRZLGBK_thread = 0;
pthread_mutex_t qrzlgbk_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t qrzlgbk_cond = PTHREAD_COND_INITIALIZER;

//Socket *QRZlgbk_socket = 0;

enum QRZlgbk_STATES {DISCONNECTED, CONNECTING, CONNECTED};
int  QRZlgbk_state = DISCONNECTED;
bool QRZlgbk_exit = false;
bool QRZlgbk_enabled = false;
bool QRZlgbk_active = false;
bool connect_to_QRZlgbk = false;

Address addr;

//static bool logged_in = false;
//bool getSessionKey(string& sessionpage);
void Lookup_init(void);
//const char* POST_DATA;
string POST_DATA;
string qrzreply;
string urlAddr = "logbook.qrz.com";
string HttpAddr ="http://logbook.qrz.com/api";
string usrAPIkey =  "KEY=ABDC-EFD1-1234-FAEC";//"KEY=HHHH-HHHH-HHHH-HHHH";// enter your user Key here
struct hostent *QRZserver;
struct sockaddr_in serv_addr;
int QRZlgbk_socket = 0;
int portno = 80;
int bytes, sent, received, total, message_size;

char response[4096];
//======================================================================
//
//======================================================================
void show_qrzerr(string message)
{
    if (message.empty()) return;
    if (!brws_tcpip_stream) return;
    if (message[message.length()-1] != '\n') message += '\n';
    LOG_DEBUG("error: %s",message.c_str());
    //brws_tcpip_stream->addstr(message, FTextBase::CTRL);
    //brws_tcpip_stream->redraw();

#ifdef QRZLGBK_DEBUG
    string pname = "TempDir";
    pname.append("dxcdebug.txt", "a");
    FILE *dxcdebug = fl_fopen(pname.c_str(), "a");
    fprintf(dxcdebug, "[E]:%s\n", message.c_str());
    fclose(dxcdebug);
#endif
}

void show_qrz_stream(string message)
{
    size_t p;
    while ((p = message.find("\r")) != string::npos) message.erase(p,1);
    if (message[message.length()-1] != '\n') message += '\n';
    LOG_DEBUG("tx_stream: %s",message.c_str());
    //brws_tcpip_stream->insert_position(brws_tcpip_stream->messageer()->length());
    //brws_tcpip_stream->addstr(message, FTextBase::XMIT);

#ifdef QRZLGBK_DEBUG
    string pname = "TempDir";
    pname.append("dxcdebug.txt", "a");
    FILE *dxcdebug = fl_fopen(pname.c_str(), "a");
    fprintf(dxcdebug, "[T]:%s\n", message.c_str());
    fclose(dxcdebug);
#endif
}
//======================================================================
//
//======================================================================

bool qrzconnect_changed;
bool connect_to_qrzcom;

void QRZlgbk_doconnect()
{
    if (connect_to_QRZlgbk) {
        string temp = "Connecting to ";

        //Address addr = Address(urlAddr.c_str(),0,"tcp");

        try {
            if (QRZlgbk_socket) {
/*
                QRZlgbk_socket->shut_down();
                QRZlgbk_socket->close();
                delete QRZlgbk_socket;
*/
                /* close the socket */
                close(QRZlgbk_socket);
                QRZlgbk_socket = 0;
                QRZlgbk_state = DISCONNECTED;
            }

            //urlAddr.append("logbook.qrz.com");// http://logbook.qrz.com/api
            temp.append(urlAddr.c_str()).append(" port:0");
            /* create the socket*/
            QRZlgbk_socket = socket(AF_INET, SOCK_STREAM, 0);
            if (QRZlgbk_socket < 0) LOG_ERROR("ERROR opening socket");
            else LOG_DEBUG("QRZlgbk_socket = %d", QRZlgbk_socket);

            QRZserver = gethostbyname(urlAddr.c_str());
            if (QRZserver == NULL) LOG_ERROR("ERROR, no such host: '%s'", urlAddr.c_str());
            else{
                /* build the server's Internet address */
                  bzero((char *) &serv_addr, sizeof(serv_addr));
                  serv_addr.sin_family = AF_INET;
                  bcopy((char *)QRZserver->h_addr,
                    (char *)&serv_addr.sin_addr.s_addr, QRZserver->h_length);
                  serv_addr.sin_port = htons(portno);
                //LOG_DEBUG("ip addr: %s", QRZserver->h_addr_list[0]);
                //LOG_DEBUG(" build the server's Internet address complete");
            }
/*
            // fill in the structure
            memset(&serv_addr,0,sizeof(serv_addr));
            serv_addr.sin_family = AF_INET;
            serv_addr.sin_port = htons(portno);
            memcpy(&serv_addr.sin_addr.s_addr,QRZserver->h_addr,QRZserver->h_length);
            LOG_DEBUG("serv_addr setup complete");
*/
            /* connect the socket */
            if (connect(QRZlgbk_socket,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) LOG_ERROR("ERROR connecting");
            else{

                addr = Address(urlAddr.c_str(),portno,"tcp");
                LOG_DEBUG("QRZlgbk_socket is connected to: %s:%d",addr.get_node().c_str(), portno);
            }
/*
            Address addr = Address(urlAddr.c_str(),portno,"tcp");
            LOG_DEBUG("Service: %s",addr.get_service().c_str());
            LOG_DEBUG("Node: %s",addr.get_node().c_str());
            QRZlgbk_socket = new Socket( addr);
            QRZlgbk_socket->set_nonblocking(true);
            QRZlgbk_socket->set_timeout((double)(QRZLGBK_SOCKET_TIMEOUT / 1000.0));
            QRZlgbk_socket->connect();

            QRZlgbk_state = CONNECTING;
*/

            QRZLGBK_connect_timeout =
                (QRZLGBK_CONNECT_TIMEOUT) / (QRZLGBK_SOCKET_TIMEOUT + QRZLGBK_LOOP_TIME);
            connect_to_QRZlgbk = !connect_to_QRZlgbk;

        } catch (const SocketException& e) {
            LOG_ERROR("%s", e.what() );
/*            delete QRZlgbk_socket;*/
            /* close the socket */
            close(QRZlgbk_socket);
            QRZlgbk_socket = 0;
            QRZlgbk_state = DISCONNECTED;
            LOG_ERROR("%s", temp.c_str());
            qrzconnect_changed = false;

            //LOG_DEBUG("Service: %s",addr.get_service().c_str());
            //LOG_DEBUG("Node: %s",addr.get_node().c_str());
        }
    }
    else {
        if (!QRZlgbk_socket){
            LOG_ERROR("QRZlgbk_socket not Found!");
            return;
        }

        qrzconnect_changed = false;
        try {
             LOG_DEBUG("QRZ POST msg: %s", POST_DATA.c_str());
/*
            if (QRZlgbk_socket->send(POST_DATA) != POST_DATA.length() || QRZlgbk_socket->recv(qrzreply) == 0) {
                    qrzreply = "Request timed out";
              }
*/

            /* send the request */
            //message = POST_DATA.c_str();

            //Sending Http header
//               bzero(&message,sizeof(message));
               char postdata[POST_DATA.length()+1];
               sprintf(postdata,"%s",POST_DATA.c_str());
               char httpAddrChr[HttpAddr.length()+1];
               sprintf(httpAddrChr,"%s",HttpAddr.c_str());
               char usrAPIkeyChr[usrAPIkey.length()+1];
               sprintf(usrAPIkeyChr,"%s", usrAPIkey.c_str());
               char message[4096];
               //sprintf(message,"POST HTTP/1.1\r\nAccept: */*\r\nReferer: %s\r\nAccept-Language: en-us\r\nContent-Type: application/x-www-form-urlencoded\r\nAccept-Encoding: gzip,deflate\r\nUser-Agent: Mozilla/4.0\r\nContent-Length: %d\r\nPragma: no-cache\r\nConnection: keep-alive\r\n\r\n%s&%s", httpAddrChr, (int)strlen(postdata), usrAPIkeyChr, postdata);
               //sprintf(message,"POST %s&%s HTTP/1.1\r\nAccept: */*\r\nReferer: %s\r\nAccept-Language: en-us\r\nContent-Type: application/x-www-form-urlencoded\r\nAccept-Encoding: gzip,deflate\r\nUser-Agent: Mozilla/4.0\r\nContent-Length: %d\r\nPragma: no-cache\r\nConnection: keep-alive\r\n\r\n", usrAPIkeyChr, postdata, httpAddrChr, (int)strlen(postdata));
               //sprintf(message,"POST %s HTTP/1.1\r\nAccept: */*\r\nReferer: %s\r\nAccept-Language: en-us\r\nContent-Type: application/x-www-form-urlencoded\r\nAccept-Encoding: gzip,deflate\r\nUser-Agent: Mozilla/4.0\r\nContent-Length: %d\r\nPragma: no-cache\r\nConnection: keep-alive\r\n\r\n %s", usrAPIkeyChr, httpAddrChr, (int)strlen(postdata), postdata);
               sprintf(message,"POST %s HTTP/1.0\r\nContent-Length: %d\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\n%s&%s", httpAddrChr,(int)strlen(usrAPIkeyChr)+(int)strlen(postdata)+1,usrAPIkeyChr,postdata);

               LOG_DEBUG("QRZ POST msg: %s", message);

            total = strlen(message);
            sent = 0;

            do {
                bytes = write(QRZlgbk_socket,message+sent,total-sent);
                if (bytes < 0)
                    LOG_ERROR("ERROR writing message to socket");
                if (bytes == 0)
                    break;
                sent+=bytes;
            } while (sent < total);
            LOG_DEBUG("POST sent to %s", addr.get_node().c_str());
            // receive the response
            memset(response,0,sizeof(response));
            total = sizeof(response)-1;
            LOG_DEBUG("Server Response Length; %d", total);
            received = 0;
            do {
                bytes = read(QRZlgbk_socket,response+received,total-received);
                if (bytes < 0)
                    LOG_ERROR("ERROR reading response from socket");
                if (bytes == 0)
                    break;
                received+=bytes;
                LOG_DEBUG("Bytes Rcvd from Server: %d", received);
            } while (received < total);
             LOG_DEBUG("Server Rply Complete");
            if (received == total)
                LOG_ERROR("ERROR storing complete response from socket");

            /* close the socket */
            close(QRZlgbk_socket);

            /* process response */
            LOG_DEBUG("Response:\n%s\n",response);

//            LOG_DEBUG("QRZ REPLY: %s", qrzreply.c_str());

        } catch (const SocketException& e) {
            LOG_ERROR("%s", e.what() );
            REQ(show_qrzerr, e.what());
        }

        MilliSleep(50);
/*
        QRZlgbk_socket->shut_down();
        QRZlgbk_socket->close();
        delete QRZlgbk_socket;
*/
        QRZlgbk_socket = 0;
        QRZlgbk_state = DISCONNECTED;
        QRZlgbk_active = false;
        LOG_INFO("Disconnected from QRZLogBkServer");
    }

}

void QRZlgbk_connect(bool val)
{
    qrzconnect_changed = true;
    connect_to_QRZlgbk = val;
}

//======================================================================
// QRZlgbk_entry(string val)
//======================================================================

void QRZlgbk_entry(string val)
{
    POST_DATA.clear();
    POST_DATA = "ACTION=INSERT&ADIF=";//JMH ADDED 20180425
    POST_DATA.append(val.c_str());
    //POST_DATA.append(usrAPIkey.c_str()).append(val.c_str());

}

//======================================================================
// QRZlgbk_busy(void)
//======================================================================

bool QRZlgbk_busy(void)
{
    return QRZlgbk_active;

}


//======================================================================
// Receive tcpip data stream
//======================================================================
void QRZlgbk_recv_data()
{
    if (!QRZlgbk_socket) return;
    string tempmessage;
    try {
        guard_lock qrzlgbk_lock(&qrzlgbk_mutex);
/*       QRZlgbk_socket->recv(tempmessage);*/

        memset(response,0,sizeof(response));
        total = sizeof(response)-1;
        received = 0;
        do {
            bytes = read(QRZlgbk_socket,response+received,total-received);
            if (bytes < 0)
                LOG_ERROR("ERROR reading response from socket");
            if (bytes == 0)
                break;
            received+=bytes;
        } while (received < total);

        if (received == total)
            LOG_ERROR("ERROR storing complete response from socket");
        else tempmessage.append(response);


        if (tempmessage.empty()) {
            if (QRZlgbk_state == CONNECTING) {
                QRZLGBK_connect_timeout--;
                if (QRZLGBK_connect_timeout <= 0) {
                    REQ(show_qrzerr, "Connection attempt timed out");
                    QRZlgbk_state = DISCONNECTED;
/*
                    QRZlgbk_socket->shut_down();
                    QRZlgbk_socket->close();
                    delete QRZlgbk_socket;
*/
                    /* close the socket */
                    close(QRZlgbk_socket);
                    QRZlgbk_socket = 0;
                }
            }
            return;
        }
        if (QRZlgbk_state == CONNECTING) {
            QRZlgbk_state = CONNECTED;
            //REQ(dxc_label);

            LOG_INFO( "Connected to QRZ.com logbookAPI %s:%s",
                "http://logbook.qrz.com/api",
                POST_DATA.c_str() );
        }
        LOG_DEBUG("QRZ LogBookAPI response: %s",tempmessage.c_str());
        //REQ(parse_DXcluster_stream, tempmessage); // for qrzlogbook not expecting to get back anything
    } catch (const SocketException& e) {
        LOG_ERROR("Error %d, %s", e.error(), e.what());
    }
}

//======================================================================
//
//======================================================================
void QRZlgbk_close(void)
{
    if (!QRZlgbk_enabled) return;

    if ((QRZlgbk_state != DISCONNECTED) && QRZlgbk_socket) {
        QRZlgbk_connect(false);
        int n = 500;
        while ((QRZlgbk_state != DISCONNECTED) && n) {
            MilliSleep(10);
            n--;
        }
        if (n == 0) {
            LOG_ERROR("%s", _("Failed to shut down QRZlgbk socket"));
            fl_message2(_("Failed to shut down QRZlgbk socket"));
            exit(1);
            return;
        }
    }

    QRZlgbk_exit = true;
    pthread_join(QRZLGBK_thread, NULL);
    QRZlgbk_enabled = false;
    QRZlgbk_active = false;

    LOG_INFO("%s", "dxserver thread terminated. ");

    if (QRZlgbk_socket) {
/*
        QRZlgbk_socket->shut_down();
        QRZlgbk_socket->close();
*/
        /* close the socket */
        close(QRZlgbk_socket);
        QRZlgbk_socket = 0;
    }

}


//======================================================================
// Thread loop
//======================================================================
void *qrzlgbk_loop(void *args)
{
    SET_THREAD_ID(QRZLGBK_TID);

    while(1) {
        MilliSleep(QRZLGBK_LOOP_TIME);//QRZLGBK_LOOP_TIME; defined at top of pg
        if (QRZlgbk_exit) break;
        if (qrzconnect_changed) QRZlgbk_doconnect();
        if (QRZlgbk_state != DISCONNECTED) QRZlgbk_recv_data();
    }
	// exit the DXCC thread
	SET_THREAD_CANCEL();
	return NULL;
}

//======================================================================
// QRZ_thread
//======================================================================

void QRZlgbk_init(void)
{
    ENSURE_THREAD(FLMAIN_TID);
    QRZlgbk_active = true;
    if (QRZLGBK_thread)
        return;
    QRZlgbk_exit = false;
    QRZlgbk_enabled = false;
    //QRZLGBK_thread = new pthread_t;
    if (pthread_create(&QRZLGBK_thread, NULL, qrzlgbk_loop, NULL) != 0) {
        LOG_ERROR("QRZLGBK_thread: %s", "pthread_create failed");
        return;
    }
    QRZlgbk_enabled = true;
    MilliSleep(10);
}




