The sdriqpkg directory is obsolete and will be removed in a future release. It was used to support
the SDR-IQ by RfSpace. Use the hardware file quisk_hardware_sdriq.py instead.
